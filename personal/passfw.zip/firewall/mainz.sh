#!/bin/sh

. ./setenv.sh
./ssh_pass.exp a2t-c-ssh.mainz.de.ibm.com $username $password
