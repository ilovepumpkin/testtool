#!/bin/sh

. ./setenv.sh
./pass.exp 9.123.196.219 $username $password
