#!/bin/sh

. ./setenv.sh
./pass.exp 9.48.150.12 $username $password
