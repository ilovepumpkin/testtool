#!/bin/sh

. ./setenv.sh
./pass.exp rqmtuc03.storage.tucson.ibm.com $username $password
