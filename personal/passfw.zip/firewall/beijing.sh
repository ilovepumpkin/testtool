#!/bin/sh

. ./setenv.sh
./pass.exp 9.181.24.23 $username $password
