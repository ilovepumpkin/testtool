#!/bin/sh

. ./setenv.sh
./pass.exp aztlanmgmt.gdl.mex.ibm.com $username $password
