#!/bin/sh

. ./setenv.sh
./pass.exp w3.ssd.hursley.ibm.com $username $password
