#!/bin/sh

username=shenrui@cn.ibm.com
password=te4sowcw
