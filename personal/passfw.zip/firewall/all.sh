#!/bin/sh

./austin.sh
./mexico.sh
./mainz.sh
./shanghai.sh
./tucson.sh
./hursley.sh
